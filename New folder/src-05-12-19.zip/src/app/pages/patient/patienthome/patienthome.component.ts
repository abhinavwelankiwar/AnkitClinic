import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patienthome',
  templateUrl: './patienthome.component.html',
  styleUrls: ['./patienthome.component.css']
})
export class PatienthomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testresults',
  templateUrl: './testresults.component.html',
  styleUrls: ['./testresults.component.css']
})
export class TestresultsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

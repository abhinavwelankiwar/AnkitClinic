export interface Admin {
  adminId: number;
  firstName: string;
  lastName: string;
  gender: string;
  dateOfBirth: Date;
  contactNumber: string;
  age: number;
  altContactNumber: string;
  email: string;
  password: string;
  securityQue: string;
  securityAns: string;
}
